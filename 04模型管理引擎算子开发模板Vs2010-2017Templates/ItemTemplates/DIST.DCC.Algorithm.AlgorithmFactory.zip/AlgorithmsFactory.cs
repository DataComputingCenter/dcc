﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using DIST.DCC.Core.Algorithm;
using System.Reflection;

namespace $rootnamespace$
{
    /// <summary>
    /// 算子创建工厂，该类为全局类，类名称必须为AlgorithmsFactory
    /// </summary>
    [Serializable]
    public class $safeitemname$ : IAlgorithmAssemblyMetaInfo
    {
        #region 私有变量
        private List<IAlgorithm> _algorithmList = new List<IAlgorithm>();
        private List<string> _fileNames = new List<string>();
        private Version _version;
        private static IAlgorithmAssemblyMetaInfo _algorithmAssemblyMetaInfo;
        #endregion

        #region 属性

        /// <summary>
        /// 算子数量
        /// </summary>
        public int AlgorithmCount
        {
            get
            {
                return _algorithmList.Count;
            }
        }

        /// <summary>
        /// 程序集版本
        /// </summary>
        public Version pVersion
        {
            get
            {
                return _version;
            }

            set
            {
                _version = value;
            }
        }

        /// <summary>
        /// 算子依赖文件名称
        /// </summary>
        public List<string> FileNames
        {
            get
            {
                return _fileNames;
            }

            set
            {
                _fileNames = value;
            }
        }
        #endregion

        #region 构造函数
        /// <summary>
        /// 构造函数
        /// </summary>
        public $safeitemname$()
        {
            //程序集版本号
            Assembly ass = Assembly.GetExecutingAssembly();
            _version = ass.GetName().Version;
            //算子实例
            IAlgorithm alg0 = new ComputingAlgorithmClass();
            //添加算子
            _algorithmList.Add(alg0);
        }
        #endregion

        #region 方法函数
        /// <summary>
        /// 获取满足条件的算子
        /// </summary>
        /// <param name="where">查询表达式</param>
        /// <returns></returns>
        public IEnumerable<IAlgorithm> GetAlgorithm(Expression<Func<IAlgorithm, bool>> where)
        {
            return _algorithmList.Where(where.Compile()).ToArray();
        }

        /// <summary>
        /// 获取算子数量
        /// </summary>
        /// <returns></returns>
        public int GetAlgorithmCount()
        {
            return _algorithmList.Count;
        }

        /// <summary>
        /// 获取所有算子
        /// </summary>
        /// <returns></returns>
        public IEnumerable<IAlgorithm> GetAllAlgorithm()
        {
            return _algorithmList.ToArray();
        }

        /// <summary>
        /// 添加一个算子
        /// </summary>
        /// <param name="algorithm">算子</param>
        /// <returns></returns>
        public bool AddAlgorithm(IAlgorithm algorithm)
        {
            if (!_algorithmList.Contains(algorithm))
            {
                _algorithmList.Add(algorithm);
                return true;
            }
            else
                return false;
        }

        /// <summary>
        /// 移除算子
        /// </summary>
        /// <param name="algorithm">算子</param>
        /// <returns></returns>
        public bool RemoveAlgorithm(IAlgorithm algorithm)
        {
            if (_algorithmList.Contains(algorithm))
            {
                _algorithmList.Remove(algorithm);
                return true;
            }
            else
                return false;
        }

        /// <summary>
        /// 移除所有算子
        /// </summary>
        /// <param name="match"></param>
        /// <returns></returns>
        public int RemoveAllAlgorithm(Predicate<IAlgorithm> match = null)
        {
            if (match != null)
            {
                return _algorithmList.RemoveAll(match);
            }
            else
            {
                int i = _algorithmList.Count;
                _algorithmList.Clear();
                return i;
            }
        }

        /// <summary>
        /// 获取所有算子元数据
        /// </summary>
        /// <returns></returns>
        public IEnumerable<IAlgorithmMetaInfo> GetAllAlgorithmInfos()
        {
            List<IAlgorithmMetaInfo> algMetaInfos = new List<IAlgorithmMetaInfo>();
            foreach (var alg in _algorithmList)
            {
                algMetaInfos.Add(alg.AlgorithmMetaInfo);
            }
            return algMetaInfos.ToArray();
        }

        /// <summary>
        /// 添加算子依赖文件
        /// </summary>
        /// <param name="fileName"></param>
        public void AddDependentFileName(string fileName)
        {
            if (!_fileNames.Contains(fileName))
                _fileNames.Add(fileName);
        }

        /// <summary>
        /// 删除算子依赖文件
        /// </summary>
        /// <param name="fileName"></param>
        public void DeleteDendentFileName(string fileName)
        {
            if (_fileNames.Contains(fileName))
                _fileNames.Remove(fileName);
        }

        /// <summary>
        /// 获取算子所有依赖文件
        /// </summary>
        /// <returns></returns>
        public IEnumerable<string> DependentFiles()
        {
            return _fileNames.ToArray();
        }

        /// <summary>
        /// 创建算子程序集信息
        /// </summary>
        /// <returns></returns>
        public static IAlgorithmAssemblyMetaInfo CreateAlgorithmAssembltMetaInfo()
        {
            if (_algorithmAssemblyMetaInfo == null)
                _algorithmAssemblyMetaInfo = new AlgorithmAssemblyMetaInfo();
            return _algorithmAssemblyMetaInfo;
        }

        /// <summary>
        /// 获取算子程序集信息
        /// </summary>
        /// <returns></returns>
        public static IAlgorithmAssemblyMetaInfo GetAlgorithmAssembltMetaInfo()
        {
            return CreateAlgorithmAssembltMetaInfo();
        }

        /// <summary>
        /// 重置算子查询,置当前算子索引到1
        /// </summary>
        public void ResetAlgorithm()
        {
            throw new NotImplementedException();
        }
        #endregion
    }
}
