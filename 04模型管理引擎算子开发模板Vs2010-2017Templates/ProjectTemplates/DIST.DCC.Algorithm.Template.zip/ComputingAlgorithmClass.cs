﻿using System;
using DIST.DCC.Core.Algorithm;

namespace $safeprojectname$
{
    /// <summary>
    /// 算子类
    /// </summary>
    [Serializable]
    public class ComputingAlgorithmClass : IAlgorithm
    {
        #region 私有变量
        /// <summary>
        /// 算子输入
        /// </summary>
        protected ComputingAlgorithmInput _algorithmInput = new ComputingAlgorithmInput();
        /// <summary>
        /// 算子输出
        /// </summary>
        protected ComputingAlgorithmOutput _algorithmOutput = new ComputingAlgorithmOutput();
        /// <summary>
        /// 算子元数据
        /// </summary>
        protected IAlgorithmMetaInfo _algorithmMetaInfo;
        #endregion

        #region 事件
        /// <summary>
        /// 计算过程变化事件
        /// </summary>
        public event ShowProcessStepHandler ProgressChange;
        /// <summary>
        /// 显示计算进度事件
        /// </summary>
        public event ShowProcessInfoHandler ShowProcessInfo;
        /// <summary>
        /// 输出计算日志事件
        /// </summary>
        public event AddLogHandler AddLog;
        #endregion

        #region 属性
        /// <summary>
        /// 算子输入
        /// </summary>
        public IAlgorithmInput AlgorithmInput
        {
            get
            {
                return this._algorithmInput;
            }

            set
            {
                this._algorithmInput = value as ComputingAlgorithmInput;
            }
        }
        /// <summary>
        /// 算子元数据
        /// </summary>
        public IAlgorithmMetaInfo AlgorithmMetaInfo
        {
            get
            {
                return _algorithmMetaInfo;
            }
        }
        /// <summary>
        /// 算子输出
        /// </summary>
        public IAlgorithmOutput AlgorithmOutput
        {
            get
            {
                return this._algorithmOutput;
            }

            set
            {
                this._algorithmOutput = value as ComputingAlgorithmOutput;
            }
        }
        /// <summary>
        /// 是否需要自我配置，即自带配置界面
        /// 默认为不需要
        /// </summary>
        public bool IsSelfConfig
        {
            get
            {
                return false;
            }
        }
        #endregion

        #region 构造函数
        /// <summary>
        /// 构造函数，在构造函数中需要初始化元数据
        /// </summary>
        public ComputingAlgorithmClass()
        {
            _algorithmMetaInfo = new AlgorithmMetaInfo(this);
        }
        #endregion

        #region 方法
        /// <summary>
        /// 执行计算方法
        /// </summary>
        /// <returns></returns>
        public bool Run()
        {
            //添加：在这里添加算子的执行逻辑程序
            _algorithmOutput.Sum = _algorithmInput.FirstNum + _algorithmInput.LastNum;
            return true;
        }

        /// <summary>
        /// 自我配置
        /// </summary>
        /// <returns></returns>
        public bool SelfConfig()
        {
            throw new NotImplementedException();
        }
        #endregion

        #region 私有函数
       
        #endregion
    }
}
