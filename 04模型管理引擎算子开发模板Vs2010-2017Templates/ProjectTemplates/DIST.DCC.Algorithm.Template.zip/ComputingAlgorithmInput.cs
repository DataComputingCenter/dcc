﻿using System;
using DIST.DCC.Core.Algorithm;
namespace $safeprojectname$
{
    /// <summary>
    /// 算子的输入参数
    /// </summary>
    [Serializable]
    public class ComputingAlgorithmInput : AlgorithmInput
    {
        
        /// <summary>
        /// 算子输入1
        /// </summary>
        public double FirstNum
        {
            get
            {
                return Convert.ToDouble(base.GetValue("FirstNum"));
            }
            set
            {

                SetValue("FirstNum", value);
            }
        }
        /// <summary>
        /// 算子输入2
        /// </summary>
        public double LastNum
        {
            get
            {
                return Convert.ToDouble(base.GetValue("LastNum"));
            }
            set
            {

                SetValue("LastNum", value);
            }
        }
        /// <summary>
        /// 构造函数，需要在构造函数中注册算子的输入参数
        /// </summary>
        public ComputingAlgorithmInput()
        {
            //添加自己的代码：注册算子的输入
            //如下面的程序实例
            //作者自己修改
            base.RegisteProperty("FirstNum", "double", 0, false, false, 100, false, false, "算子输入1", "算子输入1");
            base.RegisteProperty("LastNum", "double", 0, false, false, 8, true, false, "算子输入2", "算子输入2", false, 0);
        }
        public override string GetValue(string name, BomSerializeFormatEnum format)
        {
            switch (format)
            {
                case BomSerializeFormatEnum.xml:
                    throw new NotSupportedException("暂时不支持xml的输出");
                case BomSerializeFormatEnum.json:
                default:
                    {
                        return Newtonsoft.Json.JsonConvert.SerializeObject(GetValue(name));
                    }
            }
        }
        public override bool SetValue(string name, string value, BomSerializeFormatEnum format)
        {
            switch (format)
            {
                case BomSerializeFormatEnum.xml:
                    throw new NotSupportedException("暂时不支持xml的输出");
                case BomSerializeFormatEnum.json:
                default:
                    {
                        object obj = null;
                        if (name == "FirstNum")
                            obj = Newtonsoft.Json.JsonConvert.DeserializeObject<double>(value);
                        else if (name == "LastNum")
                            obj = Newtonsoft.Json.JsonConvert.DeserializeObject<double>(value);
                        else throw new Exception("没有属性名称为" + name + "的属性");
                        return SetValue(name, obj);
                    }
            }
        }
    }
}
