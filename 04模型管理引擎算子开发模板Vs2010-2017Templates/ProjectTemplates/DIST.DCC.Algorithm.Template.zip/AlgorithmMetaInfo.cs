﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DIST.DCC.Core.Algorithm;

namespace $safeprojectname$
{
    /// <summary>
    /// 算子元数据
    /// </summary>
    [Serializable]
    public class AlgorithmMetaInfo : IAlgorithmMetaInfo
    {
        #region 字段
        private string _alias = "求和算子";
        private string _code = "000000";
        private string _name = "SumComputingAlgorithmClass";
        private string _type = "求和算子类型";
        private string _version = "1.0.0.0";
        protected IAlgorithm _algorithm;
        private IAlgorithmAssemblyMetaInfo _algAssMetaInfo;
        #endregion

        #region 属性
        /// <summary>
        /// 算子别名
        /// </summary>
        public string Alias
        {
            get
            {
                return _alias;
            }

            set
            {
                _alias = value;
            }
        }

        /// <summary>
        /// 算子编码
        /// </summary>
        public string Code
        {
            get
            {
                return _code;
            }

            set
            {
                _code = value;
            }
        }

        /// <summary>
        /// 算子名称
        /// </summary>
        public string Name
        {
            get
            {
                return _name;
            }
        }

        /// <summary>
        /// 算子
        /// </summary>
        public IAlgorithm pAlgorithm
        {
            get
            {
                return _algorithm;
            }
        }

        /// <summary>
        /// 算子输入
        /// </summary>
        public IAlgorithmInput pAlgorithmInput
        {
            get
            {
                return _algorithm.AlgorithmInput;
            }
        }

        /// <summary>
        /// 算子输出
        /// </summary>
        public IAlgorithmOutput pAlgorithmOutput
        {
            get
            {
                return _algorithm.AlgorithmOutput;
            }
        }

        /// <summary>
        /// 算子程序集信息
        /// </summary>
        public IAlgorithmAssemblyMetaInfo pAssemblyMetaInfo
        {
            get
            {
                return _algAssMetaInfo;
            }
        }

        /// <summary>
        /// 算子类型
        /// </summary>
        public string Type
        {
            get
            {
                return _type;
            }
        }

        /// <summary>
        /// 算子版本
        /// </summary>
        public string Version
        {
            get
            {
                return _version;
            }

            set
            {
                _version = value;
            }
        }
        #endregion

        #region 构造函数
        /// <summary>
        /// 构造函数
        /// </summary>
        /// <param name="algorithm"></param>
        public AlgorithmMetaInfo(IAlgorithm algorithm)
        {
            if (_algorithm != null)
                _algorithm = algorithm;
            _algAssMetaInfo = AlgorithmsFactory.GetAlgorithmAssembltMetaInfo();
        }
        #endregion
    }
}
