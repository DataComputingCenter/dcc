﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DIST.DCC.Core.Algorithm;
using DIST.DCC.Core.BOM;
using DIST.DCC.Core.BOM.Output;

namespace $safeprojectname$
{
    /// <summary>
    /// 算子的输出参数
    /// </summary>
    [Serializable]
    public class ComputingAlgorithmOutput : AlgorithmOutput
    {
        //添加自己代码：在这里写算子输出参数
        //如下
        /// <summary>
        /// 算子输出1，这里是实例，作者自己删除
        /// </summary>
        private double _sum = 0.0;
        /// <summary>
        /// 算子输出1，这里是实例，作者自己删除
        /// </summary>
        public double Sum
        {
            get
            {
                return _sum;
            }
            set
            {
                _sum = value;
                this.SetValue("Sum", value);
            }
        }
        /// <summary>
        /// 构造函数，需要在构造函数中注册算子的输出参数
        /// </summary>
        public ComputingAlgorithmOutput()
        {
            //添加自己的代码：注册算子的输出
            //如下面的程序实例
            //作者自己修改
            base.RegisteProperty("Sum", "double", null, true, true, 100, false, false, "计算结果", "计算结果");
        }
        public override string GetValue(string name, BomSerializeFormatEnum format)
        {
            switch (format)
            {
                case BomSerializeFormatEnum.xml:
                    throw new NotSupportedException("暂时不支持xml的输出");
                case BomSerializeFormatEnum.json:
                default:
                    {
                        return Newtonsoft.Json.JsonConvert.SerializeObject(GetValue(name));
                    }
            }
        }
        public override bool SetValue(string name, string value, BomSerializeFormatEnum format)
        {
            switch (format)
            {
                case BomSerializeFormatEnum.xml:
                    throw new NotSupportedException("暂时不支持xml的输出");
                case BomSerializeFormatEnum.json:
                default:
                    {
                        object obj = null;
                        if (name == "Sum")
                            obj = Newtonsoft.Json.JsonConvert.DeserializeObject<double>(value);
                        else throw new Exception("没有属性名称为" + name + "的属性");
                        return SetValue(name, obj);
                    }
            }
        }
    }
}
